This is an example portable sound library for use with SDL.
The API can be found in the file ~/Library/Frameworks/SDL_sound.framework/Headers/SDL_sound.h

The source code is available from:
http://www.icculus.org/SDL_sound/

This library is distributed under the terms of the GNU LGPL license: http://www.gnu.org/copyleft/lesser.html
